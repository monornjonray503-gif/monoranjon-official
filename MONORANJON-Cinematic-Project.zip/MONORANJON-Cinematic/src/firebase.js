import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

// This is the latest MONORANJON Web App configuration previously supplied.
// Firebase Web API keys identify the project; secure access with Firebase Rules.
const firebaseConfig = {
  apiKey: "AIzaSyDgQL9rdxShrn_mM2fEocpzKikiGhxsu3g",
  authDomain: "monoranjon-digital-2026.firebaseapp.com",
  projectId: "monoranjon-digital-2026",
  storageBucket: "monoranjon-digital-2026.firebasestorage.app",
  messagingSenderId: "729857204814",
  appId: "1:729857204814:web:be569cc61d16301c4ad91f",
  measurementId: "G-Z810CSBEET"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const googleProvider = new GoogleAuthProvider();
