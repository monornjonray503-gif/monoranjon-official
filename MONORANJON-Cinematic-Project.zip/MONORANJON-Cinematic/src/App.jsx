import { useEffect, useMemo, useState } from "react";
import {
  onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signInWithPopup, signOut,
  updateProfile
} from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, getDoc, getDocs,
  onSnapshot, orderBy, query, serverTimestamp, setDoc, where
} from "firebase/firestore";
import { getDownloadURL, ref, uploadBytes } from "firebase/storage";
import {
  ArrowUpRight, Menu, X, Globe2, ShieldCheck, Code2, Palette,
  Cloud, Smartphone, ShoppingBag, Search, LogIn, LogOut,
  LayoutDashboard, Plus, Trash2, ImagePlus, UserRound, Sparkles
} from "lucide-react";
import { auth, db, storage, googleProvider } from "./firebase";

const PROFILE_FALLBACK = "/assets/profile.jpg";
const CATEGORIES = ["All", "Games", "Apps", "Software", "Websites", "Design", "Other"];

function friendlyError(error) {
  const map = {
    "auth/email-already-in-use": "এই ইমেইলে আগে থেকেই অ্যাকাউন্ট আছে।",
    "auth/invalid-credential": "ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।",
    "auth/weak-password": "কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড দিন।",
    "auth/popup-closed-by-user": "Google sign-in বন্ধ করা হয়েছে।",
    "permission-denied": "Firebase Rules অনুমতি দেয়নি। Rules ও Admin UID পরীক্ষা করুন।"
  };
  return map[error.code] || error.message || "একটি সমস্যা হয়েছে।";
}

async function uploadImage(file, folder) {
  if (!file) throw new Error("আগে একটি ছবি নির্বাচন করুন।");
  if (!file.type.startsWith("image/")) throw new Error("শুধু image ফাইল আপলোড করা যাবে।");
  if (file.size > 5 * 1024 * 1024) throw new Error("ছবির সাইজ ৫ MB-এর কম হতে হবে।");
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const storageRef = ref(storage, `${folder}/${Date.now()}-${safe}`);
  await uploadBytes(storageRef, file, { contentType: file.type });
  return getDownloadURL(storageRef);
}

export default function App() {
  const [user, setUser] = useState(null);
  const [admin, setAdmin] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [register, setRegister] = useState(false);
  const [authError, setAuthError] = useState("");
  const [busy, setBusy] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [lang, setLang] = useState("bn");
  const [section, setSection] = useState("home");
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("All");
  const [search, setSearch] = useState("");
  const [settings, setSettings] = useState({});
  const [form, setForm] = useState({ name: "", category: "Apps", price: "", description: "", link: "" });
  const [productImage, setProductImage] = useState(null);
  const [notice, setNotice] = useState("");

  const t = (bn, en) => lang === "bn" ? bn : en;

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (current) => {
      setUser(current);
      setAdmin(false);
      if (current) {
        try {
          const snap = await getDoc(doc(db, "admins", current.uid));
          setAdmin(snap.exists() && snap.data().active === true);
          await setDoc(doc(db, "users", current.uid), {
            name: current.displayName || "",
            email: current.email || "",
            updatedAt: serverTimestamp()
          }, { merge: true });
        } catch (e) {
          console.error("Account role/profile check:", e);
        }
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const q = query(collection(db, "products"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, snap => {
      setProducts(snap.docs.map(d => ({ id: d.id, ...d.data() }))
        .filter(p => p.status === "published"));
    }, err => {
      console.error(err);
      setNotice("পণ্য লোড হয়নি। Firestore Rules পরীক্ষা করুন।");
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, "settings", "site"), snap => {
      setSettings(snap.exists() ? snap.data() : {});
    }, err => console.error(err));
    return () => unsub();
  }, []);

  const filtered = useMemo(() => products.filter(p => {
    const matchCategory = category === "All" || p.category === category;
    const q = search.toLowerCase();
    const matchSearch = (p.name || "").toLowerCase().includes(q) ||
      (p.description || "").toLowerCase().includes(q);
    return matchCategory && matchSearch;
  }), [products, category, search]);

  async function handleAuth(e) {
    e.preventDefault();
    setBusy(true); setAuthError("");
    const fd = new FormData(e.currentTarget);
    const email = fd.get("email").trim();
    const password = fd.get("password");
    const name = (fd.get("name") || "").trim();
    try {
      if (register) {
        if (!name) throw new Error("আপনার নাম লিখুন।");
        const result = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(result.user, { displayName: name });
        await setDoc(doc(db, "users", result.user.uid), {
          name, email, createdAt: serverTimestamp()
        });
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
      setAuthOpen(false);
    } catch (err) { setAuthError(friendlyError(err)); }
    finally { setBusy(false); }
  }

  async function googleLogin() {
    setBusy(true); setAuthError("");
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await setDoc(doc(db, "users", result.user.uid), {
        name: result.user.displayName || "",
        email: result.user.email || "",
        updatedAt: serverTimestamp()
      }, { merge: true });
      setAuthOpen(false);
    } catch (err) { setAuthError(friendlyError(err)); }
    finally { setBusy(false); }
  }

  async function addProduct(e) {
    e.preventDefault();
    if (!admin || !user) return;
    setBusy(true); setNotice("");
    try {
      const image = await uploadImage(productImage, "products");
      await addDoc(collection(db, "products"), {
        ...form, price: Number(form.price), image,
        status: "published", createdBy: user.uid,
        createdAt: serverTimestamp()
      });
      setForm({ name: "", category: "Apps", price: "", description: "", link: "" });
      setProductImage(null);
      e.currentTarget.reset();
      setNotice("পণ্য সফলভাবে প্রকাশ হয়েছে।");
    } catch (err) { setNotice(friendlyError(err)); }
    finally { setBusy(false); }
  }

  async function removeProduct(id) {
    if (!admin || !confirm("এই পণ্যটি মুছে ফেলবেন?")) return;
    try {
      await deleteDoc(doc(db, "products", id));
      setNotice("পণ্য মুছে ফেলা হয়েছে।");
    } catch (err) { setNotice(friendlyError(err)); }
  }

  async function saveSiteImage(file, field, folder) {
    if (!admin) return;
    setBusy(true); setNotice("");
    try {
      const url = await uploadImage(file, folder);
      await setDoc(doc(db, "settings", "site"), {
        [field]: url, updatedAt: serverTimestamp()
      }, { merge: true });
      setNotice("ছবি আপডেট হয়েছে।");
    } catch (err) { setNotice(friendlyError(err)); }
    finally { setBusy(false); }
  }

  const profile = settings.profileImage || PROFILE_FALLBACK;

  function go(id) {
    setSection(id);
    setMobileOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  }

  if (!authReady) return <div className="boot"><div className="boot-mark">M</div><p>MONORANJON IS LOADING</p></div>;

  return (
    <div className="app-shell">
      <div className="ambient ambient-a" /><div className="ambient ambient-b" />
      <header className="topbar">
        <a className="brand" href="#home" onClick={() => go("home")}>
          <span className="brand-mark">M</span><span>MONORANJON</span>
        </a>
        <button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">
          {mobileOpen ? <X /> : <Menu />}
        </button>
        <nav className={mobileOpen ? "nav-links open" : "nav-links"}>
          {["home","market","services","security","about","contact"].map((id, i) => (
            <button key={id} onClick={() => go(id)}>
              {t(["হোম","মার্কেট","সার্ভিস","সিকিউরিটি","আমার সম্পর্কে","যোগাযোগ"][i],
                  ["Home","Market","Services","Security","About","Contact"][i])}
            </button>
          ))}
          {admin && <button onClick={() => go("admin")}>Admin</button>}
          {user && <button onClick={() => go("account")}>My Account</button>}
        </nav>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setLang(lang === "bn" ? "en" : "bn")} title="Language"><Globe2 size={17}/>{lang === "bn" ? "EN" : "বাং"}</button>
          {user
            ? <button className="login-btn" onClick={() => signOut(auth)}><LogOut size={16}/> Logout</button>
            : <button className="login-btn" onClick={() => { setAuthOpen(true); setRegister(false); }}><LogIn size={16}/> Login</button>}
        </div>
      </header>

      <main>
        <section id="home" className="hero section-wrap">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={15}/> {t("আমার ডিজিটাল জগতে স্বাগতম","WELCOME TO MY DIGITAL WORLD")}</div>
            <h1>{t("আইডিয়া থেকে","FROM IDEAS TO")}<br/><span>{t("ডিজিটাল বাস্তবতা","DIGITAL REALITY")}</span></h1>
            <p className="hero-lead">MONORANJON is a creative digital universe for technology, development, digital products and ideas.</p>
            <div className="hero-buttons">
              <button className="btn btn-primary" onClick={() => go("market")}>{t("মার্কেটপ্লেস দেখুন","Explore Marketplace")} <ArrowUpRight size={17}/></button>
              <button className="btn btn-glass" onClick={() => go("about")}>{t("আমার সম্পর্কে","About Me")}</button>
            </div>
            <div className="hero-metrics">
              <div><b>01</b><span>Digital Vision</span></div><div><b>∞</b><span>Creative Ideas</span></div><div><b>24/7</b><span>Online Universe</span></div>
            </div>
          </div>
          <div className="hero-art">
            <div className="ring ring-one"/><div className="ring ring-two"/><div className="ring ring-three"/>
            <div className="portrait-aura"/>
            <img className="portrait" src={profile} alt="MONORANJON profile"/>
            <div className="floating-chip chip-top"><Code2 size={17}/> DIGITAL CREATOR</div>
            <div className="floating-chip chip-bottom"><span className="live-dot"/> CREATIVE MODE</div>
            <div className="spark spark-one">✦</div><div className="spark spark-two">⌘</div>
          </div>
        </section>

        <div className="ticker"><div>✦ TECHNOLOGY　✦ DEVELOPMENT　✦ DIGITAL PRODUCTS　✦ CREATIVE SERVICES　✦ MONORANJON　</div></div>

        <section id="market" className="section-wrap content-section">
          <SectionHeading eyebrow="DIGITAL STORE" title="Digital" accent="Marketplace" desc="Discover apps, games, software, websites and creative resources."/>
          <div className="market-controls">
            <div className="searchbox"><Search size={18}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search digital products..."/></div>
            <div className="filters">{CATEGORIES.map(c => <button key={c} className={category === c ? "filter active" : "filter"} onClick={() => setCategory(c)}>{c}</button>)}</div>
          </div>
          <div className="product-grid">
            {filtered.length ? filtered.map(p => <article className="product-card" key={p.id}>
              <div className="product-image"><img src={p.image || "/assets/banner.svg"} alt={p.name}/><span>{p.category}</span></div>
              <div className="product-body"><h3>{p.name}</h3><p>{p.description}</p><div className="product-foot"><b>৳{Number(p.price || 0).toLocaleString("en-BD")}</b>{p.link ? <a href={p.link} target="_blank" rel="noreferrer">View details <ArrowUpRight size={14}/></a> : <span className="coming">Details soon</span>}</div></div>
            </article>) : <div className="empty-state">No published products found.</div>}
          </div>
        </section>

        <section id="services" className="content-section section-wrap">
          <SectionHeading eyebrow="WHAT I DO" title="Creative" accent="Services" desc="Digital solutions built around ideas and technology."/>
          <div className="service-grid">
            <Service icon={<Code2/>} title="Web Development" desc="Modern responsive websites and web applications."/>
            <Service icon={<Smartphone/>} title="App Development" desc="Application concepts, interfaces and development."/>
            <Service icon={<Palette/>} title="Design & Branding" desc="Visual identity, logos, banners and creative assets."/>
            <Service icon={<Cloud/>} title="Hosting & Deployment" desc="Deployment workflows and hosting setup assistance."/>
            <Service icon={<ShoppingBag/>} title="Digital Marketplace" desc="A curated place for digital products and resources."/>
            <Service icon={<Globe2/>} title="Backend & API" desc="Database design and secure service integrations."/>
          </div>
        </section>

        <section id="security" className="security-band section-wrap">
          <div><div className="eyebrow"><ShieldCheck size={15}/> DIGITAL SAFETY</div><h2>Learn. Protect. <span>Build Responsibly.</span></h2><p>Explore cybersecurity awareness, privacy protection, secure development and ethical technology learning.</p><div className="security-pills"><span>Security Awareness</span><span>Privacy</span><span>Ethical Learning</span><span>Web Protection</span></div></div>
          <div className="shield-art"><ShieldCheck size={112}/><span>SECURE<br/>BY DESIGN</span></div>
        </section>

        <section id="about" className="content-section section-wrap">
          <SectionHeading eyebrow="THE CREATOR" title="About" accent="MONORANJON" desc="A personal digital space for creativity, learning and building."/>
          <div className="about-card"><img src={profile} alt="Profile"/><div><span className="eyebrow">DIGITAL CREATOR</span><h3>MONORANJON FIRE</h3><p>Technology enthusiast focused on web development, digital creativity, software projects and responsible security learning.</p><button className="btn btn-primary" onClick={() => go("contact")}>Let's connect <ArrowUpRight size={16}/></button></div></div>
        </section>

        <section id="contact" className="content-section section-wrap contact-section">
          <SectionHeading eyebrow="GET IN TOUCH" title="Let's" accent="Connect" desc="For project enquiries, support and collaboration."/>
          <div className="contact-row"><a href="https://wa.me/8801845077415" target="_blank" rel="noreferrer">WhatsApp <ArrowUpRight size={16}/></a><a href="https://t.me/Monoranjonfire" target="_blank" rel="noreferrer">Telegram <ArrowUpRight size={16}/></a></div>
        </section>

        {user && <section id="account" className="content-section section-wrap">
          <SectionHeading eyebrow="PERSONAL SPACE" title="My" accent="Dashboard" desc="Your signed-in account information."/>
          <div className="panel-card"><UserRound/><div><h3>{user.displayName || "MONORANJON User"}</h3><p>{user.email}</p><small>{admin ? "Administrator account" : "Standard user account"}</small></div></div>
        </section>}

        {admin && <section id="admin" className="content-section section-wrap admin-area">
          <SectionHeading eyebrow="CONTROL CENTER" title="Admin" accent="Dashboard" desc="Manage published marketplace products and site images."/>
          {notice && <div className="notice">{notice}</div>}
          <div className="admin-grid">
            <form className="panel-card admin-form" onSubmit={addProduct}>
              <h3><Plus size={18}/> Add Product</h3>
              <input required placeholder="Product name" value={form.name} onChange={e => setForm({...form,name:e.target.value})}/>
              <select value={form.category} onChange={e => setForm({...form,category:e.target.value})}>{CATEGORIES.filter(c => c !== "All").map(c => <option key={c}>{c}</option>)}</select>
              <input required type="number" min="0" placeholder="Price in BDT" value={form.price} onChange={e => setForm({...form,price:e.target.value})}/>
              <textarea required placeholder="Product description" value={form.description} onChange={e => setForm({...form,description:e.target.value})}/>
              <input type="url" placeholder="Product URL (optional)" value={form.link} onChange={e => setForm({...form,link:e.target.value})}/>
              <label className="file-label"><ImagePlus size={17}/> Choose product image<input required type="file" accept="image/*" onChange={e => setProductImage(e.target.files?.[0] || null)}/></label>
              <button className="btn btn-primary" disabled={busy}>{busy ? "Please wait..." : "Publish Product"}</button>
            </form>
            <div className="panel-card admin-form"><h3><LayoutDashboard size={18}/> Product Manager</h3>
              {products.length ? products.map(p => <div className="manage-row" key={p.id}><span>{p.name}</span><button className="delete-btn" onClick={() => removeProduct(p.id)} title="Delete"><Trash2 size={16}/></button></div>) : <p>No published products.</p>}
            </div>
            <div className="panel-card admin-form"><h3><ImagePlus size={18}/> Site Images</h3>
              <label className="file-label">Update profile image<input type="file" accept="image/*" onChange={e => saveSiteImage(e.target.files?.[0], "profileImage", "site")}/></label>
              <label className="file-label">Update hero banner<input type="file" accept="image/*" onChange={e => saveSiteImage(e.target.files?.[0], "bannerImage", "site")}/></label>
              <p className="muted">Profile image changes are saved in Firestore settings.</p>
            </div>
          </div>
        </section>}
      </main>

      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">M</span><span>MONORANJON</span></a><p>Ideas into digital experiences.</p><small>© {new Date().getFullYear()} MONORANJON. All rights reserved.</small></footer>

      {notice && !admin && <div className="toast" role="status">{notice}</div>}

      {authOpen && <div className="modal-backdrop" onClick={() => setAuthOpen(false)}><div className="auth-modal" onClick={e => e.stopPropagation()}>
        <button className="modal-x" onClick={() => setAuthOpen(false)}><X/></button>
        <div className="brand-mark modal-mark">M</div><h2>{register ? "Create account" : "Welcome back"}</h2><p>Sign in to your MONORANJON universe.</p>
        <form onSubmit={handleAuth}>
          {register && <input name="name" required placeholder="Your name"/>}
          <input name="email" type="email" required placeholder="Email address"/>
          <input name="password" type="password" minLength="6" required placeholder="Password (minimum 6 characters)"/>
          <button className="btn btn-primary auth-submit" disabled={busy}>{busy ? "Please wait..." : register ? "Create account" : "Login"}</button>
        </form>
        <button className="google-btn" onClick={googleLogin} disabled={busy}>Continue with Google</button>
        {authError && <div className="error-text">{authError}</div>}
        <button className="switch-auth" onClick={() => {setRegister(!register);setAuthError("");}}>{register ? "Already have an account? Login" : "New here? Create an account"}</button>
      </div></div>}
    </div>
  );
}

function SectionHeading({ eyebrow, title, accent, desc }) {
  return <div className="section-heading"><div className="eyebrow">{eyebrow}</div><h2>{title} <span>{accent}</span></h2><p>{desc}</p></div>;
}
function Service({ icon, title, desc }) {
  return <article className="service-card"><div className="service-icon">{icon}</div><h3>{title}</h3><p>{desc}</p></article>;
}
