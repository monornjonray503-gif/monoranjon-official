# MONORANJON — Cinematic Digital Universe

## Included
- React + Vite frontend
- Firebase Email/Password and Google Authentication
- Firestore product catalogue
- Admin role check using `admins/{uid}` with `active: true`
- Firebase Storage product/profile/banner image uploads
- Bengali/English interface toggle
- Responsive cinematic design

## 1. Install
```bash
npm install
npm run dev
```

## 2. Firebase setup
Use the Firebase project configured in `src/firebase.js`.
In Firebase Console:
1. Authentication → Sign-in method → enable Email/Password and Google.
2. Create a Cloud Firestore database.
3. Create/enable Firebase Storage.
4. Publish `firestore.rules` in Firestore Rules.
5. Publish `storage.rules` in Storage Rules.
6. Authentication → Users: register an account and copy its UID.
7. Firestore → create collection `admins`; create a document whose ID is that UID; add boolean field `active: true`.

Do not let ordinary users create or edit admin documents. Create the first admin document manually in Firebase Console.

## 3. Add your photo
Replace `public/assets/profile.jpg` with the supplied portrait, keeping the same filename.
Optional: add `public/assets/banner.svg` as a fallback product image.

## 4. Deploy to Vercel
Push this folder to GitHub, then import the repository into Vercel. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.

## Notes
- Firebase client configuration is public by design; security must come from Firebase Security Rules.
- Admin authorization in this starter uses a Firestore admin document. For a larger production platform, use a trusted server/Cloud Function for privileged operations.
- Payments, order processing, ticketing, video hosting and server-side moderation are not implemented in this starter.
